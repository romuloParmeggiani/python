def main():
    print("Hello there")
    name = input("What's your name Mr/Mrs?\n")
    print("Nice to meet you", name)
if __name__ == "__main__":
    main()